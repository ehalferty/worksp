Date : 10/31/06 

ion Design Inc.
4410 Shoalwood
Austin, Texas  78756          
                        
Design Manager    : Darren Larson
                  : (512)260-5778
             Email: dlarson@iondsn.com
        Cell Phone: (512)630-9814

Designer Contact  : (Jacque Cottingim)
                  : (469) 644-98258
            Email : (jcottingim@ioddsn.com)

Job# XIL017 quote#  061020XIL1

README for XIL017_gerbers.zip

Files contained in the zip file:

README.1st      This file
XILlyr1.017   	Layer 1
XILlyr2.017       Layer 2
XILlyr3.017   	Layer 3
XILlyr4.017       Layer 4
XILlyr5.017   	Layer 5
XILlyr6.017       Layer 6
XILlyr7.017   	Layer 7
XILlyr8.017       Layer 8
XILlyr9.017   	Layer 9
XILlyr10.017      Layer 10
XILlyr11.017   	Layer 11
XILlyr12.017      Layer 12
XILlyr13.017   	Layer 13
XILlyr14.017      Layer 14
XILlyr15.017   	Layer 15
XILlyr16.017      Layer 16
XILsmc.017   	Soldermask Layer 1 Side (Component)
XILsms.017    	Soldermask Layer 18 Side (Solder)
XILspc.017    	Solder Paste Layer 1 Side (for Assembly ONLY)(Ref.ONLY)
XILsps.017    	Solder Paste Layer 18 Side (for Assembly ONLY)(Ref.ONLY)
XILtslk.017 	Silk Screen Layer 1 side
XILbslk.017 	Silk Screen Layer 18 side
XILfab.017    	Fabrication Drawing Page 1(for Ref. ONLY)
XILassy.017       Assembly Drawing Page 1 (for Ref. ONLY)
ncdrill1.tap   	Drill tape
nc_param.txt 	Drill tape setup file
nctape.log    	Drill tape composite file (for Reference ONLY)
XIL017.ipc     	IPC-D-356 netlist (for Checking ONLY)
art_param.txt  	Artwork Format File (for Ref. ONLY)
art_aper.txt      Artwork Aperture File (for Ref. Only)
XILcen.017	      Placement file for Assembly (for Ref. Only)
XILnet.017   	Allegro Netlist (for Ref. Only)

Notes:
