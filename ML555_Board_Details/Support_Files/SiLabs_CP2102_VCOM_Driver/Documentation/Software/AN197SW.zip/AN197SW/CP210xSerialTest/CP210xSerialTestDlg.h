// CP210xSerialTestDlg.h : header file
//

#if !defined(AFX_CP210XSERIALTESTDLG_H__265443BB_D30B_4A0B_8F95_B12F99234508__INCLUDED_)
#define AFX_CP210XSERIALTESTDLG_H__265443BB_D30B_4A0B_8F95_B12F99234508__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCP210xSerialTestDlg dialog

class CCP210xSerialTestDlg : public CDialog
{
// Construction
public:

	HANDLE m_hMaster;
	HANDLE m_hSlave;
	
	DCB m_DCBMasterInitState;
	DCB m_DCBSlaveInitState;

	bool WriteData(HANDLE handle, BYTE* data, DWORD length, DWORD* dwWritten);
	bool ReadData(HANDLE handle, BYTE* data, DWORD length, DWORD* dwRead, UINT timeout);
	
	CCP210xSerialTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCP210xSerialTestDlg)
	enum { IDD = IDD_CP210XSERIALTEST_DIALOG };
	BYTE	m_MasterPort;
	BYTE	m_SlavePort;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCP210xSerialTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCP210xSerialTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CP210XSERIALTESTDLG_H__265443BB_D30B_4A0B_8F95_B12F99234508__INCLUDED_)
